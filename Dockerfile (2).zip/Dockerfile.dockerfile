FROM php:8.1-apache
COPY . /var/www/html/
EXPOSE 80
Root Directory: /
Root Directory: telegram-order-form
